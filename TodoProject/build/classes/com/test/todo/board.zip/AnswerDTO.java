package com.test.todo.board;

import lombok.Data;

@Data
public class AnswerDTO {

	private String seq;
	private String Mseq;
	private String Qseq;
	private String Adate;
	private String content;
	private String likes;
	
	private String name;
	
}
