package com.test.todo.board;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import com.test.todo.DBUtil;
import com.test.todo.board.BoardDTO;

public class BoardDAO {

	private Connection conn;
	private Statement stat;
	private PreparedStatement pstat;
	private ResultSet rs;

	public BoardDAO() {
		conn = DBUtil.open();
	}

	public BoardDTO get(String seq) {

		try {

			String sql = "select tblBoard.*, (select nickname from tblMemberInfo where seq = tblQuestionBoard.Mseq)"
					+ "as name from tblQuestionBoard where seq = ?";

			pstat = conn.prepareStatement(sql);

			pstat.setString(1, seq);

			rs = pstat.executeQuery();

			if (rs.next()) {

				BoardDTO dto = new BoardDTO();

				dto.setSeq(rs.getString("seq"));
				dto.setNickname(rs.getString("nickname"));
				dto.setQdate(rs.getString("Qdate"));
				dto.setTitle(rs.getString("title"));
				dto.setName(rs.getString("name"));
				dto.setContent(rs.getString("content"));

				return dto;

			}

		} catch (Exception e) {
			System.out.println("BoardDAO.get");
			e.printStackTrace();
		}

		return null;
	}

	public ArrayList<BoardDTO> list() {

		try {

			String sql = "select \r\n" + "    q.qdate as qdate,\r\n" + "    q.title as title,\r\n"
					+ "    q.content as content,\r\n" + "    q.likes as likes,\r\n" + "    i.nickname as nickname,\r\n"
					+ "    i.image as image\r\n" + "from tblQuestionBoard q inner join tblMember m\r\n"
					+ "				on m.seq = q.Mseq inner join tblMemberInfo i on m.seq = i.mseq";

			pstat = conn.prepareStatement(sql);

			rs = pstat.executeQuery();

			ArrayList<BoardDTO> list = new ArrayList<BoardDTO>();

			while (rs.next()) {

				BoardDTO dto = new BoardDTO();

				dto.setQdate(rs.getString("qdate"));
				dto.setTitle(rs.getString("title"));
				dto.setContent(rs.getString("content"));
				dto.setLikes(rs.getString("likes"));
				dto.setNickname(rs.getString("nickname"));
				dto.setImage(rs.getString("image"));

				list.add(dto);

			}

			return list;

		} catch (Exception e) {
			System.out.println("BoardDAO.list");
			e.printStackTrace();
		}

		return null;
	}

	public int add(String seq, String title, String content) {
		try {

			String sql = "insert into tblQuestionBoard (seq, Mseq, Qdate, title, content, likes) "
					+ "values (seqQboard.nextVal, ?, default, ?, ?, default)";

			pstat = conn.prepareStatement(sql);

			pstat.setString(1, seq);
			pstat.setString(2, title);
			pstat.setString(3, content);

			return pstat.executeUpdate();

		} catch (Exception e) {
			System.out.println("BoardDAO.add");
			e.printStackTrace();
		}

		return 0;
	}

}
