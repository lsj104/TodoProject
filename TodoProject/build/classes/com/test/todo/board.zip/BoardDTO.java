package com.test.todo.board;

import lombok.Data;

@Data
public class BoardDTO {
	
	//질문게시판
	private String seq; 
	private String Mseq; 
	private String Qdate; 
	private String title; 
	private String content; 
	private String likes;
	
	//이름,프사
	private String name;
	private String nickname;
	private String image;
	
	
}
